# ABASIN MARKET RADAR — Android v0.4

## په دې نسخه کې څه نوي دي؟
- Binance Spot او USDⓈ-M Futures د BTCUSDT عام قیمتونه
- MEXC Spot او Contract د BTCUSDT عام قیمتونه
- Binance Spot او Futures د Order Book د ۲۰ غوره کچو Bid/Ask حجم پرتله
- د Binance 1-minute candles څخه EMA، RSI او د ۱۵ دقیقو Momentum
- د Binance Futures عام Aggregate Trades څخه د Taker Buy/Sell حجم او Delta
- د $100,000 یا پورته او له $5,000 ښکته د معاملاتي چاپونو د اندازې Proxy شمېر
- د Futures Open Interest یو اوسنی Snapshot
- وروستی Funding Rate او Mark Price
- د ۱۵ دقیقو مشاهده‌یي سیګنال؛ قوت یې احتمال یا تضمین نه دی
- لاسي Refresh او هدفمند ۱۵ ثانیې اتومات تازه کول

## مهم محدودیتونه او د معلوماتو تفسیر
- Large/Small trade buckets یوازې د عامو Aggregate Trades د اندازې اټکل دی؛ د Whale، ادارې یا Retail هویت نه ثابتوي.
- Aggressor flow د عام Binance Futures trade feed څخه راځي، نه د ټولو صرافیو له ټول بازار څخه.
- Open Interest په دې نسخه کې یوازې یو Snapshot دی؛ د زیاتېدو/کمېدو د Trend لپاره د وخت په اوږدو کې ذخیره او پرتله اړینه ده.
- Liquidation stream/heatmap لا نه دی وصل شوی.
- Capital.com CFD لا نه دی وصل؛ د رسمي API او د کارونکي مجاز لاسرسي تنظیم ته اړتیا لري.
- MEXC contract endpoint ممکن د API د بدلون یا سیمه‌ییز محدودیت له امله ناکام شي.
- دا سیستم د Spot، Futures او CFD قیمتونه د یو شان بازار په توګه نه ګڼي.
- سیګنال heuristic دی او Backtesting/Forward testing یې نه دی تصدیق کړی؛ د معاملې سپارښتنه نه ده.
- اپلیکیشن Read-only دی: حساب ته ننوتل، فرمایشونه، ایستل او معامله نه کوي.
- هېڅ API Secret په اپلیکیشن یا GitHub کې مه ساتئ.

## د Android APK جوړول د ټابلیټ له لارې
1. د ZIP فایل Extract کړئ.
2. د `abasin_v04` فولډر ټول محتویات GitHub Repository ته Upload کړئ؛ `.github` پټ فولډر هم شامل کړئ.
3. Commit changes وکړئ.
4. د Repository د Actions برخې ته لاړ شئ.
5. `Build ABASIN MARKET RADAR APK` workflow خلاص کړئ او که اړتیا وي `Run workflow` ووهئ.
6. کله چې Build بریالی شي، د `ABASIN-MARKET-RADAR-v0.4-debug-apk` Artifact ډاونلوډ کړئ.
7. Artifact ZIP Extract کړئ او `app-debug.apk` په Android ټابلیټ کې نصب کړئ.

## تخنیکي جوړښت
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35 / minSdk 26
- Gradle 8.9 په GitHub Actions کې
