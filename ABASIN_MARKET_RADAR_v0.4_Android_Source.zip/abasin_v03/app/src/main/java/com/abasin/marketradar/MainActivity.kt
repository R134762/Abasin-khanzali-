package com.abasin.marketradar

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 19, 31)
    private val panel = Color.rgb(17, 37, 53)
    private val muted = Color.rgb(157, 178, 194)
    private val mint = Color.rgb(25, 211, 162)
    private val red = Color.rgb(255, 102, 120)
    private val pool = Executors.newSingleThreadScheduledExecutor()
    private lateinit var page: LinearLayout
    private lateinit var status: TextView
    private val values = linkedMapOf<String, String>()
    private val prices = linkedMapOf<String, Double>()
    private val cards = linkedMapOf<String, TextView>()
    private val notes = linkedMapOf<String, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 28) }
        scroll.addView(page); setContentView(scroll)
        header()
        section("LIVE EXCHANGE COMPARISON")
        addMarket("BINANCE SPOT", "BTC/USDT", "binance_spot")
        addMarket("BINANCE USDⓈ-M FUTURES", "BTCUSDT Perpetual", "binance_futures")
        addMarket("MEXC SPOT", "BTC/USDT", "mexc_spot")
        addMarket("MEXC CONTRACT", "BTC_USDT Perpetual", "mexc_futures")
        addMarket("CAPITAL.COM CFD", "Bitcoin CFD", "capital")
        section("INSTITUTIONAL vs RETAIL PROXY")
        val explainer = text("Large-trade estimates use public trade-size data where available. They do not identify trader accounts or prove that a trade belongs to a whale or institution.", 13, muted)
        panel(explainer)
        section("ORDER BOOK & MOMENTUM")
        addMetric("Binance Spot top-20 imbalance", "book_spot")
        addMetric("Binance Futures top-20 imbalance", "book_futures")
        addMetric("1-minute trend / RSI / 15-minute momentum", "indicators")
        section("PUBLIC FLOW PROXIES — NOT TRADER IDENTITIES")
        addMetric("Aggressive buyer / seller flow", "flow")
        addMetric("Large-trade proxy (>= $100k)", "large_trades")
        addMetric("Small-trade proxy (< $5k)", "small_trades")
        addMetric("Futures Open Interest", "open_interest")
        addMetric("Funding rate / mark price", "funding")
        section("15-MINUTE OBSERVATION")
        val signal = text("Waiting for enough synchronized market data. No signal yet.", 16, Color.WHITE, true)
        panel(signal); notes["signal"] = signal
        val disclaimer = text("Signal strength is a heuristic score, not a probability or guarantee. Spot, Futures and CFD prices are not directly interchangeable. Read-only mode: no orders, withdrawals or account login.", 12, muted)
        page.addView(space(12)); page.addView(disclaimer)
        status = text("Connecting to public market feeds…", 12, mint)
        page.addView(space(12)); page.addView(status)
        val refresh = Button(this).apply { text = "REFRESH NOW"; setOnClickListener { refreshData() } }
        page.addView(space(10)); page.addView(refresh)
        refreshData()
        pool.scheduleAtFixedRate({ refreshData() }, 15, 15, TimeUnit.SECONDS)
    }

    private fun header() {
        page.addView(text("ABASIN MARKET RADAR", 25, Color.WHITE, true))
        page.addView(space(4)); page.addView(text("MULTI-EXCHANGE INTELLIGENCE  •  15-MINUTE HORIZON", 11, mint, true))
        page.addView(space(12))
        val chip = text("PERSONAL MARKET MONITOR  |  READ-ONLY", 11, Color.rgb(255, 204, 110), true)
        panel(chip)
    }
    private fun section(s: String) { page.addView(space(16)); page.addView(text(s, 13, mint, true)); page.addView(space(7)) }
    private fun addMarket(title: String, symbol: String, key: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(15, 13, 15, 13); setBackgroundColor(panel) }
        box.addView(text(title, 13, Color.WHITE, true)); box.addView(text(symbol, 11, muted))
        val price = text("Price: —", 21, Color.WHITE, true); box.addView(space(5)); box.addView(price)
        val detail = text("Waiting for public feed", 11, muted); box.addView(detail)
        cards[key] = price; notes[key] = detail
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 8; page.addView(box, lp)
    }
    private fun addMetric(label: String, key: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(13, 10, 13, 10); setBackgroundColor(panel) }
        row.addView(text(label, 12, muted)); val v = text("—", 15, Color.WHITE, true); row.addView(v); notes[key] = v
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 6; page.addView(row, lp)
    }
    private fun panel(v: TextView) { v.setPadding(14, 13, 14, 13); v.setBackgroundColor(panel); page.addView(v) }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(3f, 1f)
    }
    private fun space(h: Int) = TextView(this).apply { height = h }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6500; c.readTimeout = 6500; c.requestMethod = "GET"
        return try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }
    private fun refreshData() {
        Thread {
            val errors = mutableListOf<String>()
            fun fetch(key: String, url: String, field: String = "price") {
                try { val j = JSONObject(get(url)); val p = j.getString(field).toDouble(); prices[key] = p; values[key] = "OK" }
                catch (_: Exception) { errors.add(key) }
            }
            fetch("binance_spot", "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT")
            fetch("binance_futures", "https://fapi.binance.com/fapi/v1/ticker/price?symbol=BTCUSDT")
            fetch("mexc_spot", "https://api.mexc.com/api/v3/ticker/price?symbol=BTCUSDT")
            try {
                val j = JSONObject(get("https://contract.mexc.com/api/v1/contract/ticker?symbol=BTC_USDT"))
                val d = j.optJSONObject("data") ?: JSONObject()
                val p = d.optDouble("lastPrice", Double.NaN)
                if (p.isFinite() && p > 0) { prices["mexc_futures"] = p; values["mexc_futures"] = "OK" } else errors.add("mexc_futures")
            } catch (_: Exception) { errors.add("mexc_futures") }
            val spotBook = imbalance("https://api.binance.com/api/v3/depth?symbol=BTCUSDT&limit=20")
            val futBook = imbalance("https://fapi.binance.com/fapi/v1/depth?symbol=BTCUSDT&limit=20")
            val indicator = indicators()
            val flow = tradeFlow()
            val oi = openInterest()
            val funding = fundingInfo()
            runOnUiThread {
                listOf("binance_spot", "binance_futures", "mexc_spot", "mexc_futures").forEach { key ->
                    cards[key]?.text = prices[key]?.let { "Price: ${"%,.2f".format(it)} USDT" } ?: "Price: unavailable"
                    notes[key]?.text = if (values[key] == "OK") "Public ticker connected • refreshed" else "Feed unavailable / blocked / rate-limited"
                }
                notes["book_spot"]?.text = spotBook ?: "Unavailable"
                notes["book_futures"]?.text = futBook ?: "Unavailable"
                notes["indicators"]?.text = indicator ?: "Waiting for candle data"
                notes["flow"]?.text = flow?.get("summary") ?: "Trade-flow feed unavailable"
                notes["large_trades"]?.text = flow?.get("large") ?: "Unavailable"
                notes["small_trades"]?.text = flow?.get("small") ?: "Unavailable"
                notes["open_interest"]?.text = oi ?: "Unavailable"
                notes["funding"]?.text = funding ?: "Unavailable"
                val score = buildScore(spotBook, futBook, indicator, flow)
                notes["signal"]?.text = score
                status.text = "Updated: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())}  •  ${errors.size} feed(s) unavailable"
            }
        }.start()
    }
    private fun imbalance(endpoint: String): String? = try {
        val j = JSONObject(get(endpoint)); val bids = j.getJSONArray("bids"); val asks = j.getJSONArray("asks")
        var b = 0.0; var a = 0.0
        for (i in 0 until bids.length()) { val x = bids.getJSONArray(i); b += x.getString(1).toDouble() }
        for (i in 0 until asks.length()) { val x = asks.getJSONArray(i); a += x.getString(1).toDouble() }
        val pct = if (b + a == 0.0) 0.0 else (b - a) / (b + a) * 100
        "Bid/ask volume imbalance: ${"%.1f".format(pct)}%  •  ${if (pct > 5) "bid-side heavier" else if (pct < -5) "ask-side heavier" else "balanced"}"
    } catch (_: Exception) { null }
    private fun indicators(): String? = try {
        val arr = JSONArray(get("https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=60"))
        val closes = (0 until arr.length()).map { arr.getJSONArray(it).getString(4).toDouble() }
        val last = closes.last(); val emaFast = ema(closes.takeLast(12), 9); val emaSlow = ema(closes.takeLast(26), 21)
        val old15 = closes[closes.size - 16]
        val momentum15 = if (old15 == 0.0) 0.0 else (last - old15) / old15 * 100.0
        var gains = 0.0; var losses = 0.0
        for (i in closes.size - 14 until closes.size) { val d = closes[i] - closes[i-1]; if (d >= 0) gains += d else losses -= d }
        val rs = if (losses == 0.0) 100.0 else gains / losses
        val rsi = 100 - 100 / (1 + rs)
        "EMA trend: ${if (emaFast > emaSlow) "UP" else "DOWN"}  •  RSI(14): ${"%.1f".format(rsi)}  •  15m momentum: ${"%.3f".format(momentum15)}%  •  Last: ${"%,.2f".format(last)}"
    } catch (_: Exception) { null }
    private fun ema(xs: List<Double>, period: Int): Double { val k = 2.0 / (period + 1); return xs.drop(1).fold(xs.first()) { v, x -> x*k + v*(1-k) } }
    // Binance public aggregate trades: buyer-is-maker=false means buyer was the taker.
    // Size buckets are rough public-data proxies, never verified retail/institutional identities.
    private fun tradeFlow(): Map<String, String>? = try {
        val arr = JSONArray(get("https://fapi.binance.com/fapi/v1/aggTrades?symbol=BTCUSDT&limit=1000"))
        var buy = 0.0; var sell = 0.0; var largeBuy = 0; var largeSell = 0; var small = 0
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            val notional = t.getString("p").toDouble() * t.getString("q").toDouble()
            val buyerIsMaker = t.getBoolean("m")
            if (buyerIsMaker) sell += notional else buy += notional
            if (notional >= 100000.0) { if (buyerIsMaker) largeSell++ else largeBuy++ }
            if (notional < 5000.0) small++
        }
        val total = buy + sell
        val delta = if (total == 0.0) 0.0 else (buy - sell) / total * 100.0
        mapOf(
            "summary" to "Taker buy: ${"%,.0f".format(buy)} USDT • Taker sell: ${"%,.0f".format(sell)} USDT • Delta: ${"%.1f".format(delta)}%",
            "large" to "Large prints >= \$100k: ${largeBuy + largeSell} • buyer-initiated: $largeBuy • seller-initiated: $largeSell",
            "small" to "AggTrades below \$5k: $small (count proxy only; not verified retail orders)"
        )
    } catch (_: Exception) { null }

    private fun openInterest(): String? = try {
        val j = JSONObject(get("https://fapi.binance.com/fapi/v1/openInterest?symbol=BTCUSDT"))
        "Current OI: ${"%,.3f".format(j.getString("openInterest").toDouble())} BTC • single snapshot; trend needs stored history"
    } catch (_: Exception) { null }

    private fun fundingInfo(): String? = try {
        val j = JSONObject(get("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=BTCUSDT"))
        val rate = j.getString("lastFundingRate").toDouble() * 100.0
        "Last funding: ${"%.4f".format(rate)}% • Mark: ${"%,.2f".format(j.getString("markPrice").toDouble())} USDT"
    } catch (_: Exception) { null }

    private fun buildScore(s: String?, f: String?, ind: String?, flow: Map<String, String>?): String {
        if (prices["binance_spot"] == null || ind == null) return "NEUTRAL / INSUFFICIENT DATA\nNeed valid ticker and candle feeds before calculating a directional observation."
        val spot = prices["binance_spot"]!!; val fut = prices["binance_futures"]
        val basis = if (fut != null && spot != 0.0) (fut-spot)/spot*100 else 0.0
        val trendUp = ind.contains("EMA trend: UP"); val rsi = Regex("RSI\\(14\\): ([0-9.]+)").find(ind)?.groupValues?.get(1)?.toDoubleOrNull() ?: 50.0
        val mom = Regex("15m momentum: (-?[0-9.]+)%").find(ind)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        var score = 50; if (trendUp) score += 10 else score -= 10
        if (mom > 0.05) score += 8 else if (mom < -0.05) score -= 8
        if (rsi in 52.0..68.0) score += 8 else if (rsi < 48.0) score -= 8
        if (s?.contains("bid-side heavier") == true) score += 7 else if (s?.contains("ask-side heavier") == true) score -= 7
        if (f?.contains("bid-side heavier") == true) score += 7 else if (f?.contains("ask-side heavier") == true) score -= 7
        val flowDelta = flow?.get("summary")?.let { Regex("Delta: (-?[0-9.]+)%").find(it)?.groupValues?.get(1)?.toDoubleOrNull() }
        if (flowDelta != null) { if (flowDelta > 5) score += 8 else if (flowDelta < -5) score -= 8 }
        score = score.coerceIn(0,100)
        val direction = if (score >= 60) "BULLISH BIAS" else if (score <= 40) "BEARISH BIAS" else "NEUTRAL / MIXED"
        return "$direction  •  Heuristic score $score/100\nFutures-spot basis: ${"%.3f".format(basis)}%\n15-minute momentum: ${"%.3f".format(mom)}%\nAggressor flow is a public trade proxy; large/small size buckets do not identify institutions or retail traders. Open Interest is a snapshot until historical samples are stored. Liquidation feed is not yet connected. Score is not a probability."
    }
    override fun onDestroy() { pool.shutdownNow(); super.onDestroy() }
}
